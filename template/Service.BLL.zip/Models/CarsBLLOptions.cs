﻿namespace $safeprojectname$.Models
{
    public class CarsBLLOptions
    {
        public string JwtSecretKey { get; set; }
        public string WebApiUrl { get; set; }
    }
}
