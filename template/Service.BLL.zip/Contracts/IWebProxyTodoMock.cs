﻿using $safeprojectname$.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $safeprojectname$.Contracts
{
    public interface ITodosMockProxyService
    {
        Task<IEnumerable<Todo>> GetTodos();
        Task<Todo> GetTodoById(int id);
    }
}
