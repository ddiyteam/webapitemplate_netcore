﻿using AutoMapper;
using Service.BLL.Mappings;

namespace $safeprojectname$.Helpers
{
    public static class Mapper
    {
        public static IMapper GetAutoMapper()
        {
            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new CarsMapping());
                
            });
            var mapper = mockMapper.CreateMapper();
            return mapper;
        }
    }
}
