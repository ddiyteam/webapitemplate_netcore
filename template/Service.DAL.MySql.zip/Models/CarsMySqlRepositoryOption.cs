﻿namespace $safeprojectname$
{
    public class CarsMySqlRepositoryOption
    {
        public string CarsDbConnectionString { get; set; }
    }
}
