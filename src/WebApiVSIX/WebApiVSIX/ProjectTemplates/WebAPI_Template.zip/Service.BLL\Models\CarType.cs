namespace $ext_safeprojectname$.BLL.Models
{
    public enum CarType
    {
        Hatchback = 0,
        Sedan = 1,
        SUV = 2,
        Coupe = 3
    }
}
