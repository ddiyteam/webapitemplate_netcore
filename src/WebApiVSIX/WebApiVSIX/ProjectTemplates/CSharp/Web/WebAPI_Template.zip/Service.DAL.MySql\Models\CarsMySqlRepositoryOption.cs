namespace $ext_safeprojectname$.DAL.MySql
{
    public class CarsMySqlRepositoryOption
    {
        public string CarsDbConnectionString { get; set; }
    }
}
