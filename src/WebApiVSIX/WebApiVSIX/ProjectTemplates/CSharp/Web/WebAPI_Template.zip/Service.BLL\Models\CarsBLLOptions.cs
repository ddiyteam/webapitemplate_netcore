namespace $ext_safeprojectname$.BLL.Models
{
    public class CarsBLLOptions
    {
        public string JwtSecretKey { get; set; }
        public string WebApiUrl { get; set; }
    }
}
